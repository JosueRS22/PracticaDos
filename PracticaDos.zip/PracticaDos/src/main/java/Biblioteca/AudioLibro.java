package Biblioteca;
public class AudioLibro extends Libro {

    /** Subclase para AudioLibros*/
    public AudioLibro(int id, String titulo, String autor, int anio, String genero, boolean disponible) {
        super(id, titulo, autor, anio, genero, disponible);
    }

    @Override
    public String getTipo() {
        return "Audiolibro";
    }
}
