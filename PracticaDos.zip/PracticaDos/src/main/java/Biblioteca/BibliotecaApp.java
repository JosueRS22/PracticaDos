package Biblioteca;
import java.util.Scanner;

public class BibliotecaApp {

    /** Instanciación de las clases Catalogo y Gestor */
    private static final CatalogoLibros catalogoLibros = CatalogoLibros.getInstancia();
    private static final CatalogoUsuarios catalogoUsuarios = CatalogoUsuarios.getInstancia();
    private static final CatalogoPrestamos catalogoPrestamos = CatalogoPrestamos.getInstancia();
    private static final GestorPrestamos gestorPrestamos = new GestorPrestamos(catalogoPrestamos, catalogoLibros);
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        inicializarDatos();

        /** Menú interactivo */
        boolean salir = false;
        while (!salir) {
            System.out.println("--- SISTEMA DE BIBLIOTECA ---");
            System.out.println("1. Registrar nuevo libro");
            System.out.println("2. Registrar nuevo usuario");
            System.out.println("3. Prestar libro");
            System.out.println("4. Devolver libro");
            System.out.println("5. Buscar libros");
            System.out.println("6. Ver todos los libros");
            System.out.println("7. Ver todos los usuarios");
            System.out.println("8. Ver préstamos activos");
            System.out.println("9. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    registrarLibro();
                    break;
                case 2:
                    registrarUsuario();
                    break;
                case 3:
                    prestarLibro();
                    break;
                case 4:
                    devolverLibro();
                    break;
                case 5:
                    buscarLibros();
                    break;
                case 6:
                    mostrarLibros();
                    break;
                case 7:
                    mostrarUsuarios();
                    break;
                case 8:
                    mostrarPrestamosActivos();
                    break;
                case 9:
                    salir = true;
                    System.out.println("¡Sistema de biblioteca! sesión finalizada");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    /** Creación de objetos mediante el patrón Factory */
    private static void inicializarDatos() {
        catalogoLibros.agregar(Factory.crearLibro(1, "fisico", "Don Quijote de la Mancha", "Miguel de Cervantes", 1605, "Ficción"));
        catalogoLibros.agregar(Factory.crearLibro(2, "digital", "Cien años de soledad", "Gabriel García Márquez", 1967, "Novela"));
        catalogoLibros.agregar(Factory.crearLibro(3, "digital","El principito", "Antoine de Saint-Exupéry", 1943, "Fábula"));

        catalogoUsuarios.agregar(Factory.crearUsuario(101, "Profesor", "Jose Camacho", "jantonio@gmail.com", "123456789"));
        catalogoUsuarios.agregar(Factory.crearUsuario(102, "Profesor","Patricia Moreno", "patricia@gmail.com", "987654321"));
    }

    /** Solicitud de datos para añadir un nuevo libro */
    private static void registrarLibro() {
        System.out.println("--- REGISTRAR NUEVO LIBRO ---");

        System.out.print("ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Tipo: ");
        String tipo = scanner.nextLine();

        System.out.print("Título: ");
        String titulo = scanner.nextLine();

        System.out.print("Autor: ");
        String autor = scanner.nextLine();

        System.out.print("Año: ");
        int anio = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Género: ");
        String genero = scanner.nextLine();

        /** Invocar Factory para crear y añador un nuevo Libro */
        Libro libro = Factory.crearLibro(id, tipo, titulo, autor, anio, genero);
        catalogoLibros.agregar(libro);

        System.out.println("Libro registrado con éxito.");
    }

    /** Solicitud de datos para añadir un nuevo usuario */
    private static void registrarUsuario() {
        System.out.println("--- REGISTRAR NUEVO USUARIO ---");

        System.out.print("ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Tipo: ");
        String tipo = scanner.nextLine();

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        System.out.print("Teléfono: ");
        String telefono = scanner.nextLine();

        /** Invocar Factory para crear y añador un nuevo Usuario */
        Usuario usuario = Factory.crearUsuario(id, tipo, nombre, email, telefono);
        catalogoUsuarios.agregar(usuario);

        System.out.println("Usuario registrado con éxito.");
    }

    /** Solicitud de datos para añadir un nuevo prestamo */
    private static void prestarLibro() {
        System.out.println("--- PRESTAR LIBRO ---");

        System.out.print("ID del libro: ");
        int idLibro = scanner.nextInt();
        scanner.nextLine();

        System.out.print("ID del usuario: ");
        int idUsuario = scanner.nextInt();
        scanner.nextLine();

        Usuario usuario = catalogoUsuarios.buscarPorId(idUsuario);
        if (usuario == null) {
            System.out.println("Error: Usuario no encontrado.");
            return;
        }

        /** Creación del prestamo de un libro a un usuario */
        String resultado = gestorPrestamos.prestarLibro(idLibro, idUsuario);
        System.out.println(resultado);
    }

    /** Solicitud de datos para añadir un nuevo prestamo */
    private static void devolverLibro() {
        System.out.println("--- DEVOLVER LIBRO ---");

        System.out.print("ID del libro: ");
        int idLibro = scanner.nextInt();
        scanner.nextLine();

        /** Devolución de libro mediante el gestor */
        String resultado = gestorPrestamos.devolverLibro(idLibro);
        System.out.println(resultado);
    }

    /** Menú interactivo para buscar libro por filtros */
    private static void buscarLibros() {
        System.out.println("--- BUSCAR LIBRO ---");
        System.out.println("Buscar por:");
        System.out.println("1. ID");
        System.out.println("2. Título");
        System.out.println("3. Autor");
        System.out.println("4. Género");
        System.out.print("Seleccione una opción: ");
        int opcion = scanner.nextInt();
        scanner.nextLine();

        /** Buscar libro mediante el catalogo de libros */
        switch (opcion) {
            case 1:
                System.out.print("ID del libro: ");
                int idLibro = scanner.nextInt();
                scanner.nextLine();
                Libro libroPorId = catalogoLibros.buscarPorId(idLibro);
                if (libroPorId != null) {
                    System.out.println(libroPorId);
                } else {
                    System.out.println("Libro no encontrado.");
                }
                break;
            case 2:
                System.out.print("Título del libro: ");
                String titulo = scanner.nextLine();
                for (Libro l : catalogoLibros.buscarPorTitulo(titulo)) {
                    System.out.println(l);
                }
                break;
            case 3:
                System.out.print("Autor del libro: ");
                String autor = scanner.nextLine();
                for (Libro l : catalogoLibros.buscarPorAutor(autor)) {
                    System.out.println(l);
                }
                break;
            case 4:
                System.out.print("Género del libro: ");
                String genero = scanner.nextLine();
                for (Libro l : catalogoLibros.buscarPorGenero(genero)) {
                    System.out.println(l);
                }
                break;
            default:
                System.out.println("Opción no válida.");
        }
    }

    /** Mostrar todos los libros registrados */
    private static void mostrarLibros() {
        System.out.println("--- LISTADO DE LIBROS ---");
        for (Libro libro : catalogoLibros.obtenerTodos()) {
            System.out.println(libro);
        }
    }

    /** Mostrar todos los usuarios registrados */
    private static void mostrarUsuarios() {
        System.out.println("--- LISTADO DE USUARIOS ---");
        for (Usuario usuario : catalogoUsuarios.obtenerTodos()) {
            System.out.println(usuario);
        }
    }

    /** Mostrar todos los prestamos activos */
    private static void mostrarPrestamosActivos() {
        System.out.println("--- PRÉSTAMOS ACTIVOS ---");
        for (Prestamo p : catalogoPrestamos.obtenerTodos()) {
            if (!p.isDevuelto()) {
                System.out.println(p);
            }
        }
    }
}
