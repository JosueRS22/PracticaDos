package Biblioteca;
import java.util.ArrayList;

public class CatalogoLibros implements ICatalogo<Libro> {
    /**Crear una única instacia (patrón Singleton)*/
    private static CatalogoLibros instancia;
    private ArrayList<Libro> libros;

    private CatalogoLibros() {
        libros = new ArrayList<>();
    }

    public static CatalogoLibros getInstancia() {
        if (instancia == null) {
            instancia = new CatalogoLibros();
        }
        return instancia;
    }

    public void agregar(Libro libro) {
        libros.add(libro);
    }

    /**Métodos para busqueda*/
    public Libro buscarPorId(int id) {
        for (Libro libro : libros) {
            if (libro.getId() == id) 
            return libro;
        }
        return null;
    }

    public ArrayList<Libro> buscarPorTitulo(String titulo) {
        ArrayList<Libro> resultado = new ArrayList<>();
        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                resultado.add(libro);
            }
        }
        return resultado;
    }

    public ArrayList<Libro> buscarPorAutor(String autor) {
        ArrayList<Libro> resultado = new ArrayList<>();
        for (Libro libro : libros) {
            if (libro.getAutor().equalsIgnoreCase(autor)) {
                resultado.add(libro);
            }
        }
        return resultado;
    }

    public ArrayList<Libro> buscarPorGenero(String genero) {
        ArrayList<Libro> resultado = new ArrayList<>();
        for (Libro libro : libros) {
            if (libro.getGenero().equalsIgnoreCase(genero)) {
                resultado.add(libro);
            }
        }
        return resultado;
    }

    public ArrayList<Libro> obtenerTodos() {
        return libros;
    }
}
