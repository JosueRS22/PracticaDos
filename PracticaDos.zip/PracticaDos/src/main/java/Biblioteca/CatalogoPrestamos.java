package Biblioteca;
import java.util.ArrayList;

public class CatalogoPrestamos implements ICatalogo<Prestamo>{
    /**Crear una única instacia (patrón Singleton)*/
    private static CatalogoPrestamos instancia;
    private ArrayList<Prestamo> prestamos;

    private CatalogoPrestamos(){
        prestamos = new ArrayList<>();
    }

    public static CatalogoPrestamos getInstancia(){
        if (instancia == null){
            instancia = new CatalogoPrestamos();
        }
        return instancia;
    }
    
    public void agregar(Prestamo prestamo){
        prestamos.add(prestamo);
    }

    public Prestamo buscarPorId(int id){
        for (Prestamo prestamo : prestamos){
            if(prestamo.getId() == id)
            return prestamo;
        }
        return null;
    }

    public ArrayList<Prestamo> obtenerTodos(){
        return prestamos;
    }
}
