package Biblioteca;
import java.util.ArrayList;

public class CatalogoUsuarios implements ICatalogo<Usuario> {
    /**Crear una única instacia (patrón Singleton)*/
    private static CatalogoUsuarios instancia;
    private ArrayList<Usuario> usuarios;

    private CatalogoUsuarios() {
        usuarios = new ArrayList<>();
    }

    public static CatalogoUsuarios getInstancia() {
        if (instancia == null) {
            instancia = new CatalogoUsuarios();
        }
        return instancia;
    }

    public void agregar(Usuario usuario) {
        usuarios.add(usuario);
    }

    public Usuario buscarPorId(int id) {
        for (Usuario usuario : usuarios) {
            if (usuario.getId() == id) 
            return usuario;
        }
        return null;
    }

    public ArrayList<Usuario> obtenerTodos() {
        return usuarios;
    }
}