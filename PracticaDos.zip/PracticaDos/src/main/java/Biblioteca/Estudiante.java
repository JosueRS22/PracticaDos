package Biblioteca;
public class Estudiante extends Usuario {

    /**Subclase para usuarios Estudiante*/
    public Estudiante(int id, String nombre, String email, String telefono) {
        super(id, nombre, email, telefono);
    }

    @Override
    public String getTipo() {
        return "Estudiante";
    }

}
