package Biblioteca;
public class Factory {

    /**Clase para la creación de objetos Libro y Usuario (patrón Factory)*/ 
    public static Libro crearLibro(int id, String tipo, String titulo, String autor, int anio, String genero) {
        /**Creación de objeto Libro según el tipo*/
        switch (tipo.toLowerCase()) {
            case "fisico": 
                return new LibroFisico(id, titulo, autor, anio, genero, true);
            case "digital": 
                return new LibroDigital(id, titulo, autor, anio, genero, true);
            case "audiolibro": 
                return new AudioLibro(id, titulo, autor, anio, genero, true);
            default: 
                throw new IllegalArgumentException("Tipo de libro desconocido");
        }
    }

    public static Usuario crearUsuario(int id, String tipo, String nombre, String email, String telefono) {
        /**Creación de objeto Usuario según el tipo*/
        switch (tipo.toLowerCase()) {
            case "estudiante": 
                return new Estudiante(id, nombre, email, telefono);
            case "profesor": 
                return new Profesor(id, nombre, email, telefono);
            default: 
                throw new IllegalArgumentException("Tipo de usuario desconocido");
        }
    }
}
