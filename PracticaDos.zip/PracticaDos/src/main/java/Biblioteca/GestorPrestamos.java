package Biblioteca;
import java.util.Date;

/**Clase implementada para administrar los prestamos*/
public class GestorPrestamos {
    private ICatalogo<Prestamo> prestamos;
    private ICatalogo<Libro> libros;

    public GestorPrestamos(ICatalogo<Prestamo> prestamos, ICatalogo<Libro> libros) {
        this.prestamos = prestamos;
        this.libros = libros;
    }

    /**Método para el préstamo de libros*/
    public String prestarLibro(int idLibro, int idUsuario) {
        Libro libro = libros.buscarPorId(idLibro);
        /**Validar la existencia o disponibilidad del libro*/
        if (libro == null || !libro.isDisponible()) 
            return "Libro no disponible.";
            /**Validar límete de préstamos*/
            long prestamosActivos = prestamos.obtenerTodos().stream()
            .filter(p -> p.getIdUsuario() == idUsuario && !p.isDevuelto()).count();
        if (prestamosActivos >= 3) 
            return "Usuario ya tiene 3 préstamos activos.";

        /**Crear y registrar nuevo préstamo*/
        Prestamo nuevo = new Prestamo(
            prestamos.obtenerTodos().size() + 1,
            idLibro,
            idUsuario,
            new Date(),
            null,
            false
        );
        prestamos.agregar(nuevo);
        libro.setDisponible(false);
        return "Préstamo exitoso.";
    }

    /**Método para devolver libro*/
    public String devolverLibro(int idLibro) {
        for (Prestamo p : prestamos.obtenerTodos()) {
            if (p.getIdLibro() == idLibro && !p.isDevuelto()) {
                p.setDevuelto(true);
                p.setFechaDevolucion(new Date());
                Libro libro = libros.buscarPorId(idLibro);
                if (libro != null) libro.setDisponible(true);
                return "Libro devuelto.";
            }
        }
        return "Préstamo no encontrado.";
    }
}
