package Biblioteca;
import java.util.ArrayList;

/**Interfaz creada para reutilización de métodos*/
public interface ICatalogo<T> {
    /**Método para agregar objetos*/
    void agregar(T item);
    /**Método para buscar objetos según su id*/
    T buscarPorId(int id);
    /**Método para mostrar todos los objetos de un arreglo*/
    ArrayList<T> obtenerTodos();
}