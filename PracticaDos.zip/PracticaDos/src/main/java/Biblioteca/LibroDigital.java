package Biblioteca;
public class LibroDigital extends Libro {
    public LibroDigital(int id, String titulo, String autor, int anio, String genero, boolean disponible) {
        super(id, titulo, autor, anio, genero, disponible);
    }

    @Override
    public String getTipo() {
        return "Digital";
    }
}
