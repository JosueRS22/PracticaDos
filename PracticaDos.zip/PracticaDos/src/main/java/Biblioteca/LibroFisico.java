package Biblioteca;
public class LibroFisico extends Libro {
    public LibroFisico(int id, String titulo, String autor, int anio, String genero, boolean disponible) {
        super(id, titulo, autor, anio, genero, disponible);
    }

    @Override
    public String getTipo() {
        return "Físico";
    }
}
