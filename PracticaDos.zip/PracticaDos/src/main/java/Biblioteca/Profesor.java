package Biblioteca;
public class Profesor extends Usuario {
    public Profesor(int id, String nombre, String email, String telefono) {
        super(id, nombre, email, telefono);
    }

    @Override
    public String getTipo() {
        return "Profesor";
    }
}
