package Biblioteca;
/**Clase padre para los objetos tipo Usuario*/
public abstract class Usuario {
    private int id;
    private String nombre;
    private String email;
    private String telefono;

    public Usuario(int id, String nombre, String email, String telefono) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
    }

    //Obtener el tipo de Usuario
    public abstract String getTipo();

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Usuario = " +
                "ID: " + id +
                ", Tipo: " + getTipo() + 
                ", Nombre: " + nombre +
                ", Email: " + email +
                ", Telefono: " + telefono;
    }
}
