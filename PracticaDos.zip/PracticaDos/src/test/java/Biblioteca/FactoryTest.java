package Biblioteca;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;

import static org.junit.jupiter.api.Assertions.*;

public class FactoryTest {
    @Test
    public void TestCrearUsuario(){
        //given
        Usuario resultado = Factory.crearUsuario(103,
                "estudiante",
                "Josué",
                "josue@gmail.com",
                "123456789");

        //then
        assertInstanceOf(Usuario.class,resultado);
    }

    @Test
    public void TestCrearUsuarioMal(){
        //then
        assertThrows(IllegalArgumentException.class,()->{
            Usuario resultado = Factory.crearUsuario(103,
                    "falsote",
                    "Miguelon",
                    "miguel@gmail.com",
                    "123456789");
        });
    }
}
